#!/usr/bin/env bash
# jobstack 통합 테스트 스크립트
set -euo pipefail

# 기본값으로 격리 HOME 에서 실행한다(PR #17 리뷰 반영) — 아래에서 install.sh 를 실제로 돌리므로
# 그대로 두면 사용자의 ~/.claude/skills·~/.jobstack 이 바뀐다. 실제 설치 상태를 검증하려면 --real-home.
REAL_HOME=0
for arg in "$@"; do
  case "$arg" in
    --real-home) REAL_HOME=1 ;;
    -h|--help) echo "사용법: $0 [--real-home]   (기본: mktemp 격리 HOME·상태 디렉토리, 종료 시 삭제)"; exit 0 ;;
  esac
done
ISO_HOME=""
if [ "$REAL_HOME" -ne 1 ]; then
  ISO_HOME="$(mktemp -d "${TMPDIR:-/tmp}/jobstack-itest-home.XXXXXX")" || { echo "격리 HOME 생성 실패" >&2; exit 1; }
  export HOME="$ISO_HOME"
  export JOBSTACK_STATE_DIR="$HOME/.jobstack"
  trap 'rm -rf "$ISO_HOME"' EXIT
  echo "(격리 HOME: $ISO_HOME — 실제 ~/.claude/skills·~/.jobstack 은 건드리지 않습니다. 실제 설치 검증: --real-home)"
fi

SCRIPT_DIR="$(cd "$(dirname "$0")" && pwd)"
PROJECT_DIR="$(cd "$SCRIPT_DIR/.." && pwd)"
TEST_DATA="$SCRIPT_DIR/sample-data"
REPORT="$SCRIPT_DIR/test-report.md"
# 상태 루트는 프리앰블·install.sh와 동일하게 JOBSTACK_STATE_DIR 폴백을 따른다.
# (jobclaw/봇 러너처럼 JOBSTACK_STATE_DIR를 HOME과 다른 경로로 주입하는 격리 환경도 검증)
STATE_DIR="${JOBSTACK_STATE_DIR:-$HOME/.jobstack}"
PASS=0
FAIL=0
TOTAL=0

log_test() {
  TOTAL=$((TOTAL + 1))
  local status="$1"
  local name="$2"
  local detail="${3:-}"
  if [ "$status" = "PASS" ]; then
    PASS=$((PASS + 1))
    echo "  [PASS] $name"
  else
    FAIL=$((FAIL + 1))
    echo "  [FAIL] $name: $detail"
  fi
}

echo "╔══════════════════════════════════════╗"
echo "║  jobstack 통합 테스트                 ║"
echo "╚══════════════════════════════════════╝"
echo ""

# ────────────────────────────────────────
echo "## 0. 린트 게이트"
echo ""

for lint in test-preambles.sh test-skill-refs.sh test-command-style.sh test-no-home-paths.sh lint-conventions.sh run-golden.sh \
            test-script-layer.sh test-plugin-manifest.sh \
            test-fetch-diag.mjs test-wanted-verify.mjs test-is-fetch-adapter.mjs test-is-fetch-ssrf.mjs \
            test-tracker.sh test-exp.sh test-defense-map.sh test-ats-match.sh test-retro-stats.sh test-hwpx.sh \
            test-export.sh test-md2docx.mjs test-is-fetch-classify.sh test-fetch-diag-summary.sh \
            test-saramin-parser.mjs test-saramin-api.mjs test-fetch-jobs-saramin.sh \
            test-cron.sh test-learn.sh test-package-skill.sh; do
  if [ ! -x "$SCRIPT_DIR/$lint" ]; then
    log_test "FAIL" "린트: $lint" "스크립트 없음 또는 실행 권한 없음"
    continue
  fi
  if "$SCRIPT_DIR/$lint" > /dev/null 2>&1; then
    log_test "PASS" "린트: $lint"
  else
    log_test "FAIL" "린트: $lint" "위반 발견 — $SCRIPT_DIR/$lint 를 직접 실행해 확인"
  fi
done
# SKILL.md 크기·프론트매터 게이트 (U-08) — 인자가 필요해 별도 호출
if bash "$SCRIPT_DIR/test-skill-size.sh" --frontmatter > /dev/null 2>&1; then
  log_test "PASS" "린트: test-skill-size.sh --frontmatter"
else
  log_test "FAIL" "린트: test-skill-size.sh --frontmatter" "SKILL.md 300줄 초과 또는 필수 프론트매터 키 누락"
fi

# ────────────────────────────────────────
echo ""
echo "## 1. 인프라 테스트"
echo ""

# 1.1 install.sh
echo "### install.sh"
"$PROJECT_DIR/install.sh" > /dev/null 2>&1
if [ -L "$HOME/.claude/skills/auto" ]; then
  log_test "PASS" "심링크 생성 (~/.claude/skills/auto)"
else
  log_test "FAIL" "심링크 생성 (~/.claude/skills/auto)" "심링크 없음"
fi

SKILL_COUNT=$(ls -d "$HOME/.claude/skills"/{auto,strategy,resume,cover-letter,company-research,mock-interview,review,tracker,retro,portfolio,job-search,ncs,salary,experience-bank,career-history,scout-profile} 2>/dev/null | wc -l | tr -d ' ')
if [ "$SKILL_COUNT" -eq 16 ]; then
  log_test "PASS" "전체 16개 스킬 설치"
else
  log_test "FAIL" "전체 16개 스킬 설치" "설치된 수: $SKILL_COUNT"
fi

# 레거시 commands/ 심링크가 남아 있으면 안 된다 (v0.4.0 이전 설치 정리)
if ls "$HOME/.claude/commands"/{auto,cover_letter} >/dev/null 2>&1; then
  log_test "FAIL" "레거시 ~/.claude/commands 심링크 정리" "아직 존재"
else
  log_test "PASS" "레거시 ~/.claude/commands 심링크 정리"
fi

# 언더스코어 alias — README/스킬 본문이 안내하는 언더스코어 명령이 실제로 설치됐는지
ALIAS_COUNT=$(ls -d "$HOME/.claude/skills"/{cover_letter,company_research,mock_interview,job_search,experience_bank,career_history,scout_profile} 2>/dev/null | wc -l | tr -d ' ')
if [ "$ALIAS_COUNT" -eq 7 ]; then
  log_test "PASS" "언더스코어 alias 7개 설치 (/cover_letter 등)"
else
  log_test "FAIL" "언더스코어 alias 설치" "설치된 수: $ALIAS_COUNT"
fi

# 1.2 jobstack-config
echo ""
echo "### jobstack-config"
"$PROJECT_DIR/bin/jobstack-config" set test_key test_value 2>/dev/null
RESULT=$("$PROJECT_DIR/bin/jobstack-config" get test_key 2>/dev/null)
if [ "$RESULT" = "test_value" ]; then
  log_test "PASS" "config set/get"
else
  log_test "FAIL" "config set/get" "결과: $RESULT"
fi

LIST_RESULT=$("$PROJECT_DIR/bin/jobstack-config" list 2>/dev/null)
if echo "$LIST_RESULT" | grep -q "test_key"; then
  log_test "PASS" "config list"
else
  log_test "FAIL" "config list"
fi

# 기존 키 재-set 회귀 (BSD/GNU sed 이식성 — sed -i '' 버그 방지)
"$PROJECT_DIR/bin/jobstack-config" set test_key updated_value 2>/dev/null
RESULT2=$("$PROJECT_DIR/bin/jobstack-config" get test_key 2>/dev/null)
if [ "$RESULT2" = "updated_value" ]; then
  log_test "PASS" "config set 기존 키 갱신"
else
  log_test "FAIL" "config set 기존 키 갱신" "결과: $RESULT2 (기대: updated_value)"
fi

# 미설정 키는 exit 1 (프리앰블 PROACTIVE 폴백 전제)
if "$PROJECT_DIR/bin/jobstack-config" get __nonexistent_key__ >/dev/null 2>&1; then
  log_test "FAIL" "config get 미설정 키 exit 1" "exit 0 반환"
else
  log_test "PASS" "config get 미설정 키 exit 1"
fi

# 1.3 상태 디렉토리
echo ""
echo "### 상태 디렉토리"
for dir in profiles tracker company-cache interview-history analytics sessions defense-maps job-cache; do
  if [ -d "$STATE_DIR/$dir" ]; then
    log_test "PASS" "디렉토리: $STATE_DIR/$dir"
  else
    log_test "FAIL" "디렉토리: $STATE_DIR/$dir" "존재하지 않음"
  fi
done

# ────────────────────────────────────────
echo ""
echo "## 2. 프리앰블 테스트"
echo ""

# 각 스킬의 프리앰블 bash 블록 실행
for skill_dir in "$PROJECT_DIR"/{auto,strategy,resume,cover-letter,company-research,mock-interview,review,tracker,retro,portfolio,job-search,ncs,salary,experience-bank,career-history,scout-profile}; do
  skill_name=$(basename "$skill_dir")
  SKILL_FILE="$skill_dir/SKILL.md"
  if [ ! -f "$SKILL_FILE" ]; then
    log_test "FAIL" "프리앰블: $skill_name" "SKILL.md 없음"
    continue
  fi

  # YAML 프론트매터 확인
  if head -3 "$SKILL_FILE" | grep -q "^---"; then
    log_test "PASS" "YAML 프론트매터: $skill_name"
  else
    log_test "FAIL" "YAML 프론트매터: $skill_name" "--- 없음"
  fi

  # 동적 주입 프리앰블 라인 + 생성 파일 확인 (v0.4.0)
  if grep -qF '!`bash "${CLAUDE_SKILL_DIR}/scripts/preamble.sh" '"$skill_name"' "${CLAUDE_SESSION_ID}" "${CLAUDE_PLUGIN_DATA:-}"`' "$SKILL_FILE" \
     && [ -x "$skill_dir/scripts/preamble.sh" ] && [ -f "$skill_dir/references/guardrails.md" ]; then
    log_test "PASS" "프리앰블 주입·생성 파일: $skill_name"
  else
    log_test "FAIL" "프리앰블 주입·생성 파일: $skill_name" "주입 라인·scripts/preamble.sh·references/guardrails.md 중 누락"
  fi
done

# ────────────────────────────────────────
echo ""
echo "## 3. 뷰어 테스트"
echo ""

# 테스트 마크다운으로 뷰어 테스트
"$PROJECT_DIR/bin/jobstack-view" "$TEST_DATA/이력서_홍길동.md" --no-open 2>/dev/null
if [ -f "$TEST_DATA/이력서_홍길동.html" ]; then
  log_test "PASS" "뷰어: HTML 생성"
  SIZE=$(wc -c < "$TEST_DATA/이력서_홍길동.html" | tr -d ' ')
  if [ "$SIZE" -gt 1000 ]; then
    log_test "PASS" "뷰어: HTML 크기 적절 (${SIZE}B)"
  else
    log_test "FAIL" "뷰어: HTML 크기" "너무 작음: ${SIZE}B"
  fi
  # marked 렌더러 포함 확인 — 인라인(vendor) 또는 버전 고정 CDN
  if grep -q "marked@18" "$TEST_DATA/이력서_홍길동.html" || grep -q "marked.umd.js\|globalThis.marked\|\.marked=" "$TEST_DATA/이력서_홍길동.html"; then
    log_test "PASS" "뷰어: marked 렌더러 포함(인라인 또는 핀 CDN)"
  else
    log_test "FAIL" "뷰어: marked 렌더러 포함" "없음"
  fi
  # 미고정 CDN 참조가 남아 있으면 안 된다
  if grep -q "npm/marked/lib" "$TEST_DATA/이력서_홍길동.html"; then
    log_test "FAIL" "뷰어: marked 버전 미고정 CDN 참조 제거" "npm/marked/lib 발견"
  else
    log_test "PASS" "뷰어: marked 버전 미고정 CDN 참조 제거"
  fi
  # </script> 가 든 마크다운이 페이지를 깨지 않는지 (textarea 이스케이프)
  printf '# 이스케이프\n\n본문에 </script> 와 </textarea> 와 <b>태그</b> 가 있습니다.\n' > "$TEST_DATA/escape-test.md"
  "$PROJECT_DIR/bin/jobstack-view" "$TEST_DATA/escape-test.md" --no-open >/dev/null 2>&1
  if grep -q '&lt;/script&gt; 와 &lt;/textarea&gt;' "$TEST_DATA/escape-test.html" 2>/dev/null \
     && ! grep -q '본문에 </script>' "$TEST_DATA/escape-test.html"; then
    log_test "PASS" "뷰어: </script> 이스케이프"
  else
    log_test "FAIL" "뷰어: </script> 이스케이프" "원문이 그대로 삽입됨"
  fi
  rm -f "$TEST_DATA/escape-test.md" "$TEST_DATA/escape-test.html"
  # 한국어 폰트 확인
  if grep -q "Noto Sans KR" "$TEST_DATA/이력서_홍길동.html"; then
    log_test "PASS" "뷰어: 한국어 폰트 (Noto Sans KR)"
  else
    log_test "FAIL" "뷰어: 한국어 폰트"
  fi
  # 다크모드 확인
  if grep -q "prefers-color-scheme: dark" "$TEST_DATA/이력서_홍길동.html"; then
    log_test "PASS" "뷰어: 다크모드 지원"
  else
    log_test "FAIL" "뷰어: 다크모드 지원"
  fi
  # PDF 버튼 확인
  if grep -q "PDF 저장" "$TEST_DATA/이력서_홍길동.html"; then
    log_test "PASS" "뷰어: PDF 저장 버튼"
  else
    log_test "FAIL" "뷰어: PDF 저장 버튼"
  fi
  rm -f "$TEST_DATA/이력서_홍길동.html"
else
  log_test "FAIL" "뷰어: HTML 생성" "파일 없음"
fi

# ────────────────────────────────────────
echo ""
echo "## 4. 파일 감지 테스트 (auto 스킬 로직)"
echo ""

# auto 스킬이 감지할 파일 패턴 테스트
RESUME_FILES=$(find "$TEST_DATA" -maxdepth 1 -name '이력서*' -o -name 'resume*' -o -name 'CV*' 2>/dev/null | wc -l | tr -d ' ')
if [ "$RESUME_FILES" -gt 0 ]; then
  log_test "PASS" "이력서 감지: ${RESUME_FILES}건"
else
  log_test "FAIL" "이력서 감지" "파일 없음"
fi

COVER_FILES=$(find "$TEST_DATA" -maxdepth 1 -name '자소서*' -o -name '자기소개서*' -o -name 'cover-letter*' 2>/dev/null | wc -l | tr -d ' ')
if [ "$COVER_FILES" -gt 0 ]; then
  log_test "PASS" "자소서 감지: ${COVER_FILES}건"
else
  log_test "FAIL" "자소서 감지"
fi

JD_FILES=$(find "$TEST_DATA" -maxdepth 1 -name '채용*' -o -name 'JD*' -o -name 'job-posting*' 2>/dev/null | wc -l | tr -d ' ')
if [ "$JD_FILES" -gt 0 ]; then
  log_test "PASS" "채용공고 감지: ${JD_FILES}건"
else
  log_test "FAIL" "채용공고 감지"
fi

# ────────────────────────────────────────
echo ""
echo "## 5. tracker JSONL 테스트"
echo ""

TRACKER_FILE="$STATE_DIR/tracker/applications.jsonl"
# 테스트 데이터 추가
echo '{"id":"app-001","company":"네이버","position":"백엔드 개발자","status":"서류전형","applied_at":"2026-03-29","deadline":"2026-04-30","updated_at":"2026-03-29","notes":"코딩테스트 준비 필요"}' > "$TRACKER_FILE"
echo '{"id":"app-002","company":"카카오","position":"서버 개발자","status":"준비중","applied_at":"2026-03-29","deadline":"2026-05-15","updated_at":"2026-03-29","notes":""}' >> "$TRACKER_FILE"

ENTRY_COUNT=$(wc -l < "$TRACKER_FILE" | tr -d ' ')
if [ "$ENTRY_COUNT" -eq 2 ]; then
  log_test "PASS" "tracker JSONL 쓰기 (2건)"
else
  log_test "FAIL" "tracker JSONL 쓰기" "건수: $ENTRY_COUNT"
fi

# JSON 유효성 검증
if python3 -c "
import json, sys
with open('$TRACKER_FILE') as f:
    for line in f:
        json.loads(line.strip())
print('valid')
" 2>/dev/null | grep -q "valid"; then
  log_test "PASS" "tracker JSONL 유효성"
else
  log_test "FAIL" "tracker JSONL 유효성"
fi

# ────────────────────────────────────────
echo ""
echo "## 6. 프로필 저장 테스트"
echo ""

PROFILE_FILE="$STATE_DIR/profiles/default.yaml"
cat > "$PROFILE_FILE" << 'EOF'
name: 홍길동
email: hong@example.com
phone: 010-1234-5678
education:
  school: 한국대학교
  major: 컴퓨터공학
  graduation: 2022-02
  gpa: 3.8/4.5
experience:
  - company: ABC 스타트업
    role: 백엔드 개발 인턴
    period: 2021.07-2021.12
    highlights:
      - Spring Boot REST API 개발
      - Redis 캐싱 도입
certifications:
  - 정보처리기사
language:
  - TOEIC 820
target:
  roles: [백엔드 개발자]
  industries: [IT/테크]
  companies: [네이버, 카카오, 라인]
  timeline: 2026년 상반기
strengths:
  - 문제 해결 능력
  - 성능 최적화 경험
updated_at: 2026-03-29
EOF

if [ -f "$PROFILE_FILE" ]; then
  log_test "PASS" "프로필 YAML 저장"
else
  log_test "FAIL" "프로필 YAML 저장"
fi

if grep -q "name: 홍길동" "$PROFILE_FILE" && grep -q "target:" "$PROFILE_FILE"; then
  log_test "PASS" "프로필 YAML 구조 검증"
else
  log_test "FAIL" "프로필 YAML 구조 검증"
fi

# ────────────────────────────────────────
echo ""
echo "## 7. 텔레메트리 테스트"
echo ""

ANALYTICS_FILE="$STATE_DIR/analytics/skill-usage.jsonl"
echo '{"skill":"auto","ts":"2026-03-29T06:48:00Z","pid":1234}' > "$ANALYTICS_FILE"
echo '{"skill":"strategy","ts":"2026-03-29T06:50:00Z","pid":1234}' >> "$ANALYTICS_FILE"
echo '{"skill":"resume","ts":"2026-03-29T06:55:00Z","pid":1234}' >> "$ANALYTICS_FILE"

ANALYTICS_COUNT=$(wc -l < "$ANALYTICS_FILE" | tr -d ' ')
if [ "$ANALYTICS_COUNT" -ge 3 ]; then
  log_test "PASS" "텔레메트리 JSONL (${ANALYTICS_COUNT}건)"
else
  log_test "FAIL" "텔레메트리 JSONL"
fi

# ────────────────────────────────────────
echo ""
echo "════════════════════════════════════════"
echo "  테스트 결과: $PASS/$TOTAL 통과 ($FAIL 실패)"
echo "════════════════════════════════════════"

exit $FAIL
